# run_tests.py
#!/usr/bin/env python3
"""
AI代码生成系统 - 测试运行脚本
"""

import sys
import os
import argparse
import time
import subprocess
import platform
from datetime import datetime

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def print_banner():
    """打印横幅"""
    banner = """
    ╔══════════════════════════════════════════════════════════╗
    ║          AI代码生成系统 - 自动化测试框架                 ║
    ║            Automated Testing Framework                   ║
    ╚══════════════════════════════════════════════════════════╝
    """
    print(banner)


def check_gcc_on_windows():
    """在Windows上检查gcc"""
    try:
        # 方法1: 尝试运行gcc --version
        result = subprocess.run(['gcc', '--version'], 
                              capture_output=True, 
                              text=True, 
                              shell=True)
        return result.returncode == 0
    except:
        try:
            # 方法2: 检查MinGW安装
            result = subprocess.run(['where', 'gcc'], 
                                  capture_output=True, 
                                  text=True, 
                                  shell=True)
            return result.returncode == 0 and 'gcc' in result.stdout
        except:
            # 方法3: 检查常见安装路径
            common_paths = [
                r"C:\MinGW\bin\gcc.exe",
                r"C:\msys64\mingw64\bin\gcc.exe",
                r"C:\msys64\usr\bin\gcc.exe",
                r"C:\Program Files\mingw-w64\*\mingw64\bin\gcc.exe",
                r"C:\Program Files (x86)\mingw-w64\*\mingw32\bin\gcc.exe"
            ]
            
            for path in common_paths:
                if os.path.exists(path):
                    return True
            
            return False


def check_requirements():
    """检查系统要求"""
    print("🔍 检查系统要求...")
    
    # 检查Python版本
    python_ok = sys.version_info >= (3, 7)
    
    # 检查gcc（根据操作系统）
    gcc_ok = False
    current_os = platform.system()
    
    if current_os == "Windows":
        gcc_ok = check_gcc_on_windows()
    else:  # Linux/Mac
        try:
            result = subprocess.run(['which', 'gcc'], 
                                  capture_output=True, 
                                  text=True)
            gcc_ok = result.returncode == 0
        except:
            gcc_ok = False
    
    requirements = {
        "Python 3.7+": python_ok,
        "操作系统": f"{current_os}",
        "gcc编译器": gcc_ok,
    }
    
    all_ok = True
    for req, status in requirements.items():
        if req == "操作系统":
            print(f"   ℹ️  操作系统: {status}")
            continue
            
        if status:
            print(f"   ✅ {req}")
        else:
            print(f"   ❌ {req}")
            all_ok = False
    
    return all_ok


def start_app_server():
    """启动Flask应用服务器"""
    print("\n🚀 启动应用服务器...")
    
    import threading
    import time
    
    # 检查是否已经有服务器在运行
    try:
        import requests
        response = requests.get("http://127.0.0.1:5000/api/health", timeout=2)
        if response.status_code == 200:
            print("   ✅ 检测到已有服务器运行")
            return True
    except:
        pass
    
    # 启动新服务器
    def run_server():
        # 根据操作系统使用合适的命令
        if platform.system() == "Windows":
            os.system("python app.py")
        else:
            os.system("python3 app.py")
    
    server_thread = threading.Thread(target=run_server, daemon=True)
    server_thread.start()
    
    # 等待服务器启动
    print("   等待服务器启动...", end="")
    for i in range(30):  # 最多等待30秒
        try:
            import requests
            response = requests.get("http://127.0.0.1:5000/api/health", timeout=2)
            if response.status_code == 200:
                print(" ✅")
                return True
        except:
            pass
        
        print(".", end="", flush=True)
        time.sleep(1)
    
    print(" ❌")
    print("   服务器启动超时")
    return False


def run_single_test():
    """运行单个快速测试"""
    print("\n🧪 运行快速测试...")
    
    # 在函数内部导入以避免循环依赖
    from ai_client import ai_generate_testcase, ai_generate_code, test_compile_code
    
    try:
        # 生成测试用例
        testcase = ai_generate_testcase()
        print(f"   1. 生成测试用例: {testcase.get('description', 'N/A')}")
        print(f"      输入: {testcase.get('input', 'N/A')}")
        print(f"      预期输出: {testcase.get('output', 'N/A')}")
        
        # 生成代码
        code = ai_generate_code(testcase)
        print(f"   2. 生成代码: {len(code)} 字符")
        print(f"      代码片段: {code[:100]}...")
        
        # 编译测试
        result = test_compile_code(code)
        if result.get("success", False):
            print(f"   3. 编译: ✅ 成功")
            if result.get("run", {}).get("success", False):
                actual_output = result['run'].get('stdout', '').strip()
                expected_output = testcase.get('output', '').strip()
                print(f"   4. 执行: ✅ 成功")
                print(f"      实际输出: {actual_output}")
                print(f"      预期输出: {expected_output}")
                print(f"      输出匹配: {'✅' if actual_output == expected_output else '❌'}")
            else:
                print(f"   4. 执行: ❌ 失败")
                print(f"      错误: {result['run'].get('error', 'N/A')}")
        else:
            print(f"   3. 编译: ❌ 失败")
            print(f"      错误: {result.get('error', 'N/A')}")
            
        return True
        
    except Exception as e:
        print(f"   ❌ 测试失败: {str(e)}")
        return False


def check_api_health():
    """检查API服务状态"""
    try:
        import requests
        response = requests.get("http://127.0.0.1:5000/api/health", timeout=5)
        return response.status_code == 200
    except:
        return False


def check_and_install_gcc():
    """检查并指导安装gcc"""
    print("\n🔧 gcc编译器检查...")
    
    current_os = platform.system()
    
    if current_os == "Windows":
        print("   Windows系统检测到")
        print("   请按以下步骤安装gcc：")
        print("   1. 下载MinGW-w64: https://sourceforge.net/projects/mingw-w64/")
        print("   2. 安装时选择架构: x86_64")
        print("   3. 将MinGW\\bin目录添加到系统PATH环境变量")
        print("   4. 重启终端后运行: gcc --version")
        print("\n   或者安装MSYS2: https://www.msys2.org/")
        print("   安装后运行: pacman -S mingw-w64-x86_64-gcc")
        return False
    elif current_os == "Linux":
        print("   Linux系统检测到")
        print("   安装gcc命令：")
        print("   Ubuntu/Debian: sudo apt install gcc")
        print("   Fedora: sudo dnf install gcc")
        print("   Arch: sudo pacman -S gcc")
        return False
    elif current_os == "Darwin":  # macOS
        print("   macOS系统检测到")
        print("   安装gcc命令：")
        print("   brew install gcc")
        return False
    else:
        print(f"   未知操作系统: {current_os}")
        return False


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="AI代码生成系统测试框架")
    parser.add_argument("--cases", type=int, default=5, help="测试用例数量")
    parser.add_argument("--quick", action="store_true", help="快速测试")
    parser.add_argument("--no-server", action="store_true", help="不启动服务器（假设已运行）")
    parser.add_argument("--health", action="store_true", help="仅检查服务健康状态")
    parser.add_argument("--batch", type=int, help="批量生成测试用例数量")
    parser.add_argument("--skip-gcc-check", action="store_true", help="跳过gcc检查")
    
    args = parser.parse_args()
    
    # 打印横幅
    print_banner()
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"操作系统: {platform.system()}")
    print("-" * 60)
    
    # 检查健康状态
    if args.health:
        print("🏥 检查服务健康状态...")
        if check_api_health():
            print("✅ 服务正常")
            return 0
        else:
            print("❌ 服务异常")
            return 1
    
    # 检查系统要求（包括gcc）
    if not args.skip_gcc_check and not check_requirements():
        print("\n⚠️  系统要求不满足")
        
        # 询问是否继续
        response = input("\n是否继续测试？(y/N): ").strip().lower()
        if response != 'y' and response != 'yes':
            print("测试取消")
            return 1
        
        # 如果缺少gcc，提供安装指导
        current_os = platform.system()
        if current_os == "Windows":
            check_and_install_gcc()
            response = input("\n是否跳过gcc检查继续测试？(y/N): ").strip().lower()
            if response != 'y' and response != 'yes':
                return 1
    
    # 启动服务器（如果需要）
    if not args.no_server:
        if not start_app_server():
            print("\n❌ 无法启动或连接到应用服务器")
            return 1
    else:
        print("\nℹ️  跳过服务器启动，假设已有服务器运行")
    
    # 等待片刻确保服务就绪
    time.sleep(2)
    
    # 检查API连接
    print("\n🔗 检查API连接...")
    if not check_api_health():
        print("❌ 无法连接到AI服务")
        
        # 尝试手动启动
        response = input("\n是否手动启动app.py？(y/N): ").strip().lower()
        if response == 'y' or response == 'yes':
            print("启动app.py...")
            import threading
            def start_manual():
                os.system("python app.py")
            thread = threading.Thread(target=start_manual, daemon=True)
            thread.start()
            time.sleep(5)
            
            # 再次检查
            if check_api_health():
                print("✅ 服务启动成功")
            else:
                print("❌ 服务启动失败")
                return 1
        else:
            return 1
    
    print("✅ API连接正常")
    
    # 快速测试
    if args.quick:
        success = run_single_test()
        return 0 if success else 1
    
    # 批量生成测试用例
    if args.batch:
        print(f"\n📦 批量生成 {args.batch} 个测试用例...")
        from ai_client import generate_multiple_testcases
        testcases = generate_multiple_testcases(args.batch)
        print(f"   生成了 {len(testcases)} 个测试用例")
        
        for i, tc in enumerate(testcases, 1):
            print(f"   {i:2d}. {tc.get('description', '无描述')}")
        
        return 0
    
    # 运行完整测试
    print(f"\n🧪 开始完整测试，用例数: {args.cases}")
    print("-" * 60)
    
    try:
        # 在函数内部导入，避免循环依赖
        from test_api import test_full_ai_pipeline_enhanced
        results, analysis = test_full_ai_pipeline_enhanced(args.cases)
        
        # 输出最终结果
        print("\n" + "=" * 60)
        print("📊 最终测试结果汇总")
        print("=" * 60)
        
        if analysis['total_cases'] > 0:
            print(f"✅ 基础验证通过率: {analysis['basic_pass_rate']:.2f}%")
            print(f"✅ 编译成功率: {analysis['compile_pass_rate']:.2f}%")
            print(f"✅ 执行成功率: {analysis['execution_pass_rate']:.2f}%")
            print(f"✅ 输出匹配率: {analysis['output_match_rate']:.2f}%")
            
            # 性能评级
            print(f"\n⭐ 性能评级:")
            if analysis['basic_pass_rate'] >= 90:
                print("   基础验证: A (优秀)")
            elif analysis['basic_pass_rate'] >= 80:
                print("   基础验证: B (良好)")
            elif analysis['basic_pass_rate'] >= 70:
                print("   基础验证: C (一般)")
            elif analysis['basic_pass_rate'] >= 60:
                print("   基础验证: D (及格)")
            else:
                print("   基础验证: F (不及格)")
            
            if analysis['output_match_rate'] >= 90:
                print("   输出匹配: A (优秀)")
            elif analysis['output_match_rate'] >= 80:
                print("   输出匹配: B (良好)")
            elif analysis['output_match_rate'] >= 70:
                print("   输出匹配: C (一般)")
            elif analysis['output_match_rate'] >= 60:
                print("   输出匹配: D (及格)")
            else:
                print("   输出匹配: F (不及格)")
                
            print(f"\n📁 报告文件:")
            print(f"   详细结果: reports/detailed_results_*.json")
            print(f"   Word报告: reports/report_detailed_*.docx")
            print(f"   分析图表: analysis/analysis_chart_*.png")
        else:
            print("❌ 没有有效的测试结果")
            return 1
            
        return 0
        
    except Exception as e:
        print(f"\n❌ 测试执行失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())