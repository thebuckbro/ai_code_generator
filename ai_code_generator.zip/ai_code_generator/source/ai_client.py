#!/usr/bin/env python3
# coding: utf-8
"""
AI代码生成测试客户端 - 支持 C/C++/Java/Go，兼容旧版本输入方式
保留原来的 stdin 输入逻辑，不改变原来的测试管线
"""

import os
import sys
import subprocess
import tempfile
import platform
import re
import requests
import json
import time
import random
from typing import Dict, Tuple, List, Any

# ------------------------------
# AI 服务配置
# ------------------------------
API_URL = "http://127.0.0.1:5000/api"
HEALTH_URL = "http://127.0.0.1:5000/api/health"
COMPILE_URL = "http://127.0.0.1:5000/api/compile"
BATCH_URL = "http://127.0.0.1:5000/api/batch"

# ------------------------------
# 工具函数
# ------------------------------

def clean_output(output_text: str) -> str:
    """清理输出，提取数字或文本"""
    if not output_text:
        return ""
    
    # 移除常见的提示文本
    prompt_patterns = [
        r'请输入.*[:：]',
        r'输入.*[:：]', 
        r'输出.*[:：]',
        r'结果.*[:：]',
        r'请输入',
        r'输入',
        r'输出',
        r'结果',
        r'是',
        r'为',
        r':',
        r'：'
    ]
    
    cleaned = output_text
    for pattern in prompt_patterns:
        cleaned = re.sub(pattern, '', cleaned)
    
    # 提取数字
    numbers = re.findall(r'-?\d+', cleaned)
    if numbers:
        # 如果有多个数字，返回最后一个（通常是结果）
        return numbers[-1]
    else:
        # 如果没有数字，返回清理后的文本（移除空白和换行）
        cleaned = cleaned.strip()
        # 移除多余的空格和换行
        cleaned = re.sub(r'\s+', ' ', cleaned)
        return cleaned


def check_api_health() -> bool:
    """检查 API 服务状态"""
    try:
        response = requests.get(HEALTH_URL, timeout=5)
        if response.status_code == 200:
            data = response.json()
            return data.get("status") == "ok"
        return False
    except Exception as e:
        print(f"API健康检查失败: {e}")
        return False


def get_diverse_prompt() -> str:
    """获取多样化的测试用例提示词"""
    test_types = [
        "计算两个整数的和",
        "计算一个整数的平方",
        "计算两个整数的乘积",
        "判断一个整数是否为偶数",
        "计算阶乘",
        "找出两个整数中的最大值",
        "判断一个年份是否为闰年",
        "计算圆的面积",
        "摄氏温度转华氏温度",
        "计算斐波那契数列的第n项",
        "判断一个数是否为素数",
        "字符串反转",
        "计算数组的平均值",
        "查找数组中的最大值",
        "判断一个字符是否为元音字母",
        "计算三角形面积",
        "转换分钟为小时和分钟",
        "计算体脂率",
        "计算复利",
        "判断三个数是否能构成三角形",
        "计算最大公约数",
        "计算最小公倍数",
        "二进制转十进制",
        "十进制转二进制",
        "计算阶乘和",
        "判断回文数",
        "生成乘法表",
        "计算二次方程的根",
        "统计字符串中元音字母的数量",
        "计算矩阵对角线元素和"
    ]
    
    test_type = random.choice(test_types)
    
    return f"""请生成一个C语言小程序的测试用例，程序功能是：{test_type}。

请严格按照以下JSON格式返回，确保JSON格式正确：
{{
  "description": "程序功能的详细描述",
  "input": "具体的输入值，如果是多个输入用空格分隔。对于数组操作，第一个数字表示数组长度",
  "output": "具体的预期输出值",
  "constraints": "程序限制条件（如输入范围、数据类型等）",
  "example": "输入输出的具体示例"
}}

重要要求：
1. JSON格式必须正确，所有字符串都要用双引号
2. 输入和输出必须是具体的数值或字符串，不是描述
3. 对于输入，提供实际测试时使用的值
4. 对于输出，提供程序应该输出的精确值
5. 描述要清晰明确
6. 对于数组操作，input格式应为："n a1 a2 ... an"，其中n是数组长度

请确保返回的是纯JSON格式，不要包含其他任何文本。
"""


def create_diverse_testcase(test_type: str = None) -> Dict[str, Any]:
    """创建多样化的测试用例（备用函数）"""
    if not test_type:
        test_types = [
            "计算两个整数的和",
            "计算一个整数的平方", 
            "计算两个整数的乘积",
            "判断一个整数是否为偶数",
            "计算阶乘",
            "找出两个整数中的最大值",
            "判断一个年份是否为闰年"
        ]
        test_type = random.choice(test_types)
    
    testcase_templates = {
        "计算两个整数的和": {
            "description": "计算两个整数的和",
            "input": f"{random.randint(1, 100)} {random.randint(1, 100)}",
            "output": lambda x: str(eval(x.replace(' ', '+'))),
            "constraints": "输入为两个整数，范围1-100"
        },
        "计算一个整数的平方": {
            "description": "计算一个整数的平方",
            "input": str(random.randint(1, 20)),
            "output": lambda x: str(int(x) ** 2),
            "constraints": "输入为整数，范围1-20"
        },
        "计算两个整数的乘积": {
            "description": "计算两个整数的乘积",
            "input": f"{random.randint(1, 20)} {random.randint(1, 20)}",
            "output": lambda x: str(eval(x.replace(' ', '*'))),
            "constraints": "输入为两个整数，范围1-20"
        },
        "判断一个整数是否为偶数": {
            "description": "判断一个整数是否为偶数",
            "input": str(random.choice([2, 4, 6, 8, 10, 1, 3, 5, 7, 9])),
            "output": lambda x: "偶数" if int(x) % 2 == 0 else "奇数",
            "constraints": "输入为整数，输出'偶数'或'奇数'"
        },
        "计算阶乘": {
            "description": "计算一个非负整数的阶乘",
            "input": str(random.randint(0, 7)),
            "output": lambda x: str(factorial(int(x))),
            "constraints": "输入为非负整数，0≤n≤7"
        },
        "找出两个整数中的最大值": {
            "description": "找出两个整数中的最大值",
            "input": f"{random.randint(1, 100)} {random.randint(1, 100)}",
            "output": lambda x: str(max(map(int, x.split()))),
            "constraints": "输入为两个整数"
        },
        "判断一个年份是否为闰年": {
            "description": "判断一个年份是否为闰年",
            "input": str(random.choice([2000, 2004, 1900, 2024, 2023])),
            "output": lambda x: "闰年" if is_leap_year(int(x)) else "平年",
            "constraints": "输入为年份，输出'闰年'或'平年'"
        },
        "计算最小公倍数": {
            "description": "计算两个正整数的最小公倍数",
            "input": f"{random.randint(2, 20)} {random.randint(2, 20)}",
            "output": lambda x: str(calculate_lcm(x)),
            "constraints": "输入为两个正整数"
        },
        "计算最大公约数": {
            "description": "计算两个正整数的最大公约数",
            "input": f"{random.randint(2, 50)} {random.randint(2, 50)}",
            "output": lambda x: str(calculate_gcd(x)),
            "constraints": "输入为两个正整数"
        }
    }
    
    # 计算阶乘的辅助函数
    def factorial(n):
        result = 1
        for i in range(2, n + 1):
            result *= i
        return result
    
    # 判断闰年的辅助函数
    def is_leap_year(year):
        return (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)
    
    # 计算最小公倍数的辅助函数
    def calculate_lcm(input_str):
        numbers = list(map(int, input_str.split()))
        if len(numbers) >= 2:
            a, b = numbers[0], numbers[1]
            # 计算最大公约数
            def gcd(x, y):
                while y:
                    x, y = y, x % y
                return x
            return (a * b) // gcd(a, b)
        return 0
    
    # 计算最大公约数的辅助函数
    def calculate_gcd(input_str):
        numbers = list(map(int, input_str.split()))
        if len(numbers) >= 2:
            a, b = numbers[0], numbers[1]
            while b:
                a, b = b, a % b
            return a
        return 0
    
    if test_type in testcase_templates:
        template = testcase_templates[test_type]
        input_val = template["input"]
        output_val = template["output"](input_val)
        
        return {
            "description": template["description"],
            "input": input_val,
            "output": output_val,
            "constraints": template["constraints"],
            "example": f"输入: {input_val} 输出: {output_val}"
        }
    else:
        # 默认测试用例
        a, b = random.randint(1, 100), random.randint(1, 100)
        return {
            "description": "计算两个整数的和",
            "input": f"{a} {b}",
            "output": str(a + b),
            "constraints": "输入为两个整数",
            "example": f"输入: {a} {b} 输出: {a + b}"
        }


def fix_json_format(text: str) -> str:
    """修复常见的JSON格式问题"""
    # 修复未终止的字符串中的换行符
    text = re.sub(r'(\[|\{|\")([^\]\}\"]*?)(\n)([^\]\}\"]*?)(\]|\}|\")', 
                  r'\1\2\\n\4\5', text)
    
    # 修复未转义的双引号
    text = re.sub(r'([^\\])"([^"\\]*?)"([^\\])', r'\1"\2"\3', text)
    
    # 添加缺失的引号
    lines = text.split('\n')
    fixed_lines = []
    for line in lines:
        # 检查是否有未关闭的字符串
        if line.count('"') % 2 != 0:
            if line.strip().endswith('"'):
                # 开头可能缺少引号
                line = '"' + line
            else:
                # 结尾可能缺少引号
                line = line + '"'
        fixed_lines.append(line)
    
    return '\n'.join(fixed_lines)


def extract_json_from_text(text: str) -> Dict[str, Any]:
    """从文本中提取JSON结构"""
    # 查找JSON开始和结束
    start = text.find('{')
    end = text.rfind('}')
    
    if start != -1 and end != -1 and start < end:
        json_str = text[start:end+1]
        try:
            return json.loads(json_str)
        except:
            pass
    
    # 如果不行，尝试手动构建
    result = {}
    
    # 尝试提取描述
    desc_match = re.search(r'"description"\s*:\s*"([^"]+)"', text)
    if desc_match:
        result["description"] = desc_match.group(1)
    else:
        desc_match = re.search(r'描述[：:]\s*([^\n]+)', text)
        if desc_match:
            result["description"] = desc_match.group(1)
    
    # 尝试提取输入
    input_match = re.search(r'"input"\s*:\s*"([^"]+)"', text)
    if input_match:
        result["input"] = input_match.group(1)
    else:
        input_match = re.search(r'输入[：:]\s*([^\n]+)', text)
        if input_match:
            result["input"] = input_match.group(1)
    
    # 尝试提取输出
    output_match = re.search(r'"output"\s*:\s*"([^"]+)"', text)
    if output_match:
        result["output"] = output_match.group(1)
    else:
        output_match = re.search(r'输出[：:]\s*([^\n]+)', text)
        if output_match:
            result["output"] = output_match.group(1)
    
    # 如果都找到了，返回结果
    if "description" in result and "input" in result and "output" in result:
        result["constraints"] = "无"
        result["example"] = f"输入: {result['input']} 输出: {result['output']}"
        return result
    
    return None


def ai_generate_testcase() -> Dict[str, Any]:
    """调用 AI 生成多样化的测试用例"""
    try:
        # 使用多样化的提示词
        prompt = get_diverse_prompt()
        
        payload = {
            "prompt": prompt,
            "type": "testcase"
        }
        
        response = requests.post(API_URL, json=payload, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            if result.get("success"):
                result_text = result["result"].strip()
                
                # 尝试解析 JSON - 改进错误处理
                try:
                    # 先尝试直接解析
                    testcase = json.loads(result_text)
                except json.JSONDecodeError as e:
                    # 如果失败，尝试修复常见的JSON格式问题
                    print(f"JSON解析失败，尝试修复: {e}")
                    result_text = fix_json_format(result_text)
                    try:
                        testcase = json.loads(result_text)
                    except json.JSONDecodeError as e2:
                        print(f"修复后仍然解析失败: {e2}")
                        # 提取可能的JSON部分
                        testcase = extract_json_from_text(result_text)
                        if not testcase:
                            print("无法提取JSON，使用备用测试用例")
                            raise e2
                
                # 验证必要的字段
                required_fields = ["description", "input", "output"]
                if all(field in testcase for field in required_fields):
                    # 确保有完整的结构
                    if "constraints" not in testcase:
                        testcase["constraints"] = "无"
                    if "example" not in testcase:
                        testcase["example"] = f"输入: {testcase['input']} 输出: {testcase['output']}"
                    
                    # 清理输出中的换行符（如果有）
                    if isinstance(testcase.get("output"), str):
                        testcase["output"] = testcase["output"].replace('\n', ' ').strip()
                    
                    print(f"成功生成测试用例: {testcase['description'][:50]}...")
                    return testcase
                else:
                    print(f"生成的测试用例缺少必要字段: {testcase}")
                    # 创建一个多样化的测试用例
                    return create_diverse_testcase()
            else:
                print(f"AI生成测试用例API失败: {result.get('error', '未知错误')}")
                return create_diverse_testcase()
    except Exception as e:
        print(f"AI生成测试用例失败: {e}")
    
    # 失败时返回一个多样化的默认值
    return create_diverse_testcase()


def fix_lcm_code(code: str) -> str:
    """修复最小公倍数代码中的常见错误"""
    # 检查代码是否有明显问题
    if "lcm = (a * b) / gcd" in code and "gcd = a;" in code:
        # 重新生成正确的代码
        return """#include <stdio.h>

int main() {
    int a, b, original_a, original_b, gcd, lcm, temp;
    
    scanf("%d %d", &a, &b);
    
    // 保存原始值
    original_a = a;
    original_b = b;
    
    // 计算最大公约数
    while (b != 0) {
        temp = b;
        b = a % b;
        a = temp;
    }
    gcd = a;
    
    // 使用原始值计算最小公倍数
    lcm = (original_a * original_b) / gcd;
    
    printf("%d\\n", lcm);
    
    return 0;
}"""
    else:
        return code


def fix_gcd_code(code: str) -> str:
    """修复最大公约数代码中的常见错误"""
    # 检查代码是否有明显问题
    if "gcd = a;" in code and "b = a % b" in code:
        return """#include <stdio.h>

int main() {
    int a, b, temp;
    
    scanf("%d %d", &a, &b);
    
    // 处理负数
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    
    // 计算最大公约数
    while (b != 0) {
        temp = b;
        b = a % b;
        a = temp;
    }
    
    printf("%d\\n", a);
    
    return 0;
}"""
    else:
        return code


def ai_generate_code(testcase: Dict[str, Any]) -> str:
    """调用 AI 生成 C 代码"""
    try:
        # 根据测试用例类型构建更具体的提示词
        description = testcase.get('description', '')
        input_val = testcase.get('input', '')
        
        # 针对特定问题类型提供更详细的提示
        special_instructions = ""
        if "最小公倍数" in description or "lcm" in description.lower():
            special_instructions = """
特别注意：
1. 确保正确处理欧几里得算法
2. 在计算最小公倍数前，保存原始a和b的值
3. 最小公倍数公式：lcm = (原始a * 原始b) / gcd
4. 确保不会除以零
"""
        elif "最大公约数" in description or "gcd" in description.lower():
            special_instructions = """
特别注意：
1. 正确实现欧几里得算法
2. 处理负数输入
3. 确保最终结果正确
"""
        
        prompt = f"""
根据以下测试用例生成完整的C语言程序代码：

测试用例描述: {description}
输入格式: {input_val}
预期输出: {testcase.get('output', '')}
限制条件: {testcase.get('constraints', '无')}

具体要求:
1. 包含完整的main函数
2. 包含必要的头文件（如stdio.h）
3. 正确读取输入（使用scanf）
4. 实现正确的算法逻辑
5. 输出结果（只输出结果，不要输出额外提示信息）
6. 返回0表示正常退出

{special_instructions}

请生成完整、正确、可编译的C语言代码。
只返回代码，不要包含解释或其他文本。
"""
        
        payload = {
            "prompt": prompt,
            "type": "code"
        }
        
        response = requests.post(API_URL, json=payload, timeout=60)
        
        if response.status_code == 200:
            result = response.json()
            if result.get("success"):
                code = result["result"].strip()
                
                # 清理代码：移除代码块标记
                code = re.sub(r'^```[a-zA-Z]*\n', '', code)  # 移除开头的 ```c 或 ```
                code = re.sub(r'\n```$', '', code)          # 移除结尾的 ```
                
                # 修复常见的代码问题
                if "最小公倍数" in description or "lcm" in description.lower():
                    # 修复最小公倍数代码
                    code = fix_lcm_code(code)
                elif "最大公约数" in description or "gcd" in description.lower():
                    # 修复最大公约数代码
                    code = fix_gcd_code(code)
                
                print(f"成功生成代码，长度: {len(code)} 字符")
                return code
            else:
                print(f"AI生成代码失败: {result.get('error', '未知错误')}")
    except Exception as e:
        print(f"AI生成代码请求失败: {e}")
    
    # 失败时返回正确的代码
    description_lower = description.lower()
    if "最小公倍数" in description or "lcm" in description_lower:
        return """#include <stdio.h>

int main() {
    int a, b, original_a, original_b, gcd, lcm, temp;
    
    // 读取两个整数
    scanf("%d %d", &a, &b);
    
    // 保存原始值
    original_a = a;
    original_b = b;
    
    // 计算最大公约数（欧几里得算法）
    while (b != 0) {
        temp = b;
        b = a % b;
        a = temp;
    }
    gcd = a;
    
    // 计算最小公倍数
    lcm = (original_a * original_b) / gcd;
    
    // 输出结果
    printf("%d\\n", lcm);
    
    return 0;
}"""
    elif "最大公约数" in description or "gcd" in description_lower:
        return """#include <stdio.h>

int main() {
    int a, b, temp;
    
    scanf("%d %d", &a, &b);
    
    // 处理负数
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    
    // 计算最大公约数
    while (b != 0) {
        temp = b;
        b = a % b;
        a = temp;
    }
    
    printf("%d\\n", a);
    
    return 0;
}"""
    elif "阶乘" in description:
        return """#include <stdio.h>

int main() {
    int n, i;
    long long result = 1;
    
    scanf("%d", &n);
    
    for(i = 1; i <= n; i++) {
        result *= i;
    }
    
    printf("%lld\\n", result);
    
    return 0;
}"""
    else:
        return """#include <stdio.h>

int main() {
    int a, b, sum;
    
    // 读取输入
    scanf("%d %d", &a, &b);
    
    // 计算和
    sum = a + b;
    
    // 输出结果
    printf("%d\\n", sum);
    
    return 0;
}"""


def generate_multiple_testcases(count: int) -> List[Dict[str, Any]]:
    """生成多个测试用例"""
    testcases = []
    print(f"正在生成 {count} 个测试用例...")
    
    for i in range(count):
        print(f"  生成第 {i+1}/{count} 个测试用例...")
        testcase = ai_generate_testcase()
        testcases.append(testcase)
        
        # 避免请求过快
        if i < count - 1:
            time.sleep(0.5)
    
    return testcases


# ------------------------------
# 编译和运行函数
# ------------------------------

def run_c_code(code_text: str, test_input: str = "") -> Tuple[bool, str, str]:
    """编译并运行 C 代码"""
    return run_code_generic(code_text, "c", "gcc", test_input)


def run_cpp_code(code_text: str, test_input: str = "") -> Tuple[bool, str, str]:
    """编译并运行 C++ 代码"""
    return run_code_generic(code_text, "cpp", "g++", test_input)


def run_java_code(code_text: str, test_input: str = "") -> Tuple[bool, str, str]:
    """编译并运行 Java 代码"""
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            class_name = "Main"
            file_path = os.path.join(tmpdir, f"{class_name}.java")
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(code_text)
            # 编译
            compile_proc = subprocess.run(["javac", file_path], 
                                          capture_output=True, 
                                          text=True, 
                                          timeout=10)
            if compile_proc.returncode != 0:
                return False, "", compile_proc.stderr
            # 运行
            run_proc = subprocess.run(["java", "-cp", tmpdir, class_name],
                                      input=test_input, 
                                      capture_output=True, 
                                      text=True, 
                                      timeout=5)
            return True, run_proc.stdout, run_proc.stderr
    except Exception as e:
        return False, "", str(e)


def run_go_code(code_text: str, test_input: str = "") -> Tuple[bool, str, str]:
    """编译并运行 Go 代码"""
    return run_code_generic(code_text, "go", "go", test_input)


def run_code_generic(code_text: str, ext: str, compiler: str, test_input: str = "") -> Tuple[bool, str, str]:
    """通用编译运行函数"""
    try:
        current_os = platform.system()
        with tempfile.NamedTemporaryFile(mode='w', suffix=f'.{ext}', delete=False, encoding='utf-8') as f:
            f.write(code_text)
            src_file = f.name

        exe_file = ""
        
        try:
            if ext == "go":
                # Go 直接运行
                if current_os == "Windows":
                    run_proc = subprocess.run([compiler, "run", src_file],
                                              input=test_input, 
                                              capture_output=True, 
                                              text=True, 
                                              timeout=10, 
                                              shell=False)
                else:
                    run_proc = subprocess.run([compiler, "run", src_file],
                                              input=test_input, 
                                              capture_output=True, 
                                              text=True, 
                                              timeout=10)
                return True, run_proc.stdout, run_proc.stderr
            else:
                # C/C++ 需要编译
                exe_file = src_file.replace(f".{ext}", ".exe" if current_os=="Windows" else ".out")
                
                # 编译选项
                compile_cmd = [compiler, src_file, "-o", exe_file]
                if ext == "cpp":
                    compile_cmd.append("-std=c++11")
                
                compile_proc = subprocess.run(compile_cmd,
                                              capture_output=True, 
                                              text=True, 
                                              timeout=10)
                if compile_proc.returncode != 0:
                    return False, "", compile_proc.stderr
                
                # 运行
                run_cmd = [exe_file]
                if current_os == "Windows":
                    run_proc = subprocess.run(run_cmd, 
                                              input=test_input,
                                              capture_output=True, 
                                              text=True, 
                                              timeout=5,
                                              shell=True,
                                              creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0)
                else:
                    run_proc = subprocess.run(run_cmd, 
                                              input=test_input,
                                              capture_output=True, 
                                              text=True, 
                                              timeout=5)
                
                return True, run_proc.stdout, run_proc.stderr
                
        except subprocess.TimeoutExpired:
            return False, "", "执行超时"
        except Exception as e:
            return False, "", str(e)
        finally:
            # 清理临时文件
            try:
                if os.path.exists(src_file):
                    os.unlink(src_file)
                if exe_file and os.path.exists(exe_file):
                    os.unlink(exe_file)
            except:
                pass
                
    except Exception as e:
        return False, "", f"运行环境错误: {str(e)}"


# ------------------------------
# API 编译函数
# ------------------------------

def test_compile_code(code_text: str, test_input: str = "") -> Dict[str, Any]:
    """通过 API 测试代码编译"""
    try:
        payload = {
            "code": code_text,
            "input": test_input
        }
        response = requests.post(COMPILE_URL, json=payload, timeout=30)
        
        if response.status_code == 200:
            return response.json()
        else:
            return {
                "success": False,
                "error": f"API请求失败: {response.status_code}"
            }
    except Exception as e:
        return {
            "success": False,
            "error": f"编译测试失败: {str(e)}"
        }


# ------------------------------
# 判断语言类型
# ------------------------------

def detect_language(code_text: str) -> str:
    """根据代码内容简单判断语言"""
    code_lower = code_text.lower()
    if "#include" in code_lower or "int main" in code_lower:
        return "c"
    elif "using namespace std" in code_lower or "iostream" in code_lower or "#include <iostream>" in code_lower:
        return "cpp"
    elif "public class" in code_lower or "import java" in code_lower:
        return "java"
    elif "package main" in code_lower or "func main()" in code_lower:
        return "go"
    else:
        return "unknown"


def run_generated_code(code_text: str, test_input: str = "") -> Tuple[bool, str, str]:
    """根据语言类型运行代码"""
    lang = detect_language(code_text)
    print(f"检测到语言类型: {lang}")
    
    if lang == "c":
        return run_c_code(code_text, test_input)
    elif lang == "cpp":
        return run_cpp_code(code_text, test_input)
    elif lang == "java":
        return run_java_code(code_text, test_input)
    elif lang == "go":
        return run_go_code(code_text, test_input)
    else:
        # 默认为 C 语言
        print("无法识别语言类型，默认使用 C 语言")
        return run_c_code(code_text, test_input)


# ------------------------------
# 验证函数
# ------------------------------

def validate_generated_code(code_text: str, testcase: Dict) -> Dict:
    """验证生成代码"""
    result = {
        "basic_validation": True if code_text.strip() else False,
        "compile_success": False,
        "execution_success": False,
        "output_match": False,
        "error_message": "",
        "actual_output": "",
        "code_length": len(code_text)
    }

    test_input = testcase.get("input", "")
    expected_output = testcase.get("output", "")

    success, actual_output, error_msg = run_generated_code(code_text, test_input)
    result["compile_success"] = success
    result["execution_success"] = success
    result["actual_output"] = actual_output
    result["error_message"] = error_msg

    if expected_output.strip() and actual_output.strip():
        cleaned_actual = clean_output(actual_output)
        cleaned_expected = clean_output(expected_output)
        result["output_match"] = cleaned_actual == cleaned_expected

    return result


# ------------------------------
# 示例调用
# ------------------------------

if __name__ == "__main__":
    print("测试 AI 客户端功能...")
    
    # 检查服务状态
    if check_api_health():
        print("✅ API服务正常")
        
        # 生成测试用例
        print("\n生成测试用例...")
        testcase = ai_generate_testcase()
        print(f"描述: {testcase['description']}")
        print(f"输入: {testcase['input']}")
        print(f"预期输出: {testcase['output']}")
        print(f"限制: {testcase['constraints']}")
        
        # 生成代码
        print("\n生成代码...")
        code = ai_generate_code(testcase)
        print(f"代码长度: {len(code)} 字符")
        print(f"代码预览:\n{code[:200]}...")
        
        # 验证代码
        print("\n验证代码...")
        validation = validate_generated_code(code, testcase)
        print(f"编译成功: {validation['compile_success']}")
        print(f"执行成功: {validation['execution_success']}")
        print(f"输出匹配: {validation['output_match']}")
        if validation['actual_output']:
            print(f"实际输出: {validation['actual_output']}")
        if validation['error_message']:
            print(f"错误信息: {validation['error_message'][:100]}")
    else:
        print("❌ API服务异常，请确保 app.py 正在运行")
        print("启动命令: python app.py")