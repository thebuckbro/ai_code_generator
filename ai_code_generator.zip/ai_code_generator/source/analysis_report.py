# analysis_report.py
"""
AI代码生成测试结果分析报告
================================
本报告分析AI代码生成系统的性能表现，包括：
1. 基础验证通过率
2. 编译成功率
3. 执行成功率
4. 代码质量分析
5. 改进建议
"""

import json
import os
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt

def generate_analysis_report(results_file):
    """生成详细的分析报告"""
    
    # 加载测试结果
    with open(results_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    results = data.get('results', [])
    analysis = data.get('analysis', {})
    
    if not results:
        print("没有测试结果可分析")
        return
    
    print("\n" + "="*80)
    print("AI代码生成系统测试结果分析报告")
    print("="*80)
    
    # 1. 总体统计
    print("\n📊 总体统计")
    print("-"*40)
    print(f"测试时间: {analysis.get('timestamp', 'N/A')}")
    print(f"测试用例总数: {analysis.get('total_cases', 0)}")
    print(f"基础验证通过率: {analysis.get('basic_pass_rate', 0):.2f}%")
    print(f"编译成功率: {analysis.get('compile_pass_rate', 0):.2f}%")
    print(f"执行成功率: {analysis.get('execution_pass_rate', 0):.2f}%")
    print(f"平均代码长度: {analysis.get('avg_code_length', 0):.0f} 字符")
    
    # 2. 性能评级
    print("\n⭐ 性能评级")
    print("-"*40)
    
    basic_rate = analysis.get('basic_pass_rate', 0)
    compile_rate = analysis.get('compile_pass_rate', 0)
    exec_rate = analysis.get('execution_pass_rate', 0)
    
    # 基础验证评级
    if basic_rate >= 90:
        basic_grade = "A (优秀)"
    elif basic_rate >= 80:
        basic_grade = "B (良好)"
    elif basic_rate >= 70:
        basic_grade = "C (一般)"
    elif basic_rate >= 60:
        basic_grade = "D (及格)"
    else:
        basic_grade = "F (不及格)"
    
    # 编译评级
    if compile_rate >= 80:
        compile_grade = "A (优秀)"
    elif compile_rate >= 65:
        compile_grade = "B (良好)"
    elif compile_rate >= 50:
        compile_grade = "C (一般)"
    elif compile_rate >= 30:
        compile_grade = "D (较差)"
    else:
        compile_grade = "F (很差)"
    
    print(f"基础验证: {basic_grade}")
    print(f"编译验证: {compile_grade}")
    
    # 3. 常见错误分析
    print("\n🔍 常见错误分析")
    print("-"*40)
    
    error_counts = {}
    for result in results:
        error_msg = result.get('validation_result', {}).get('error_message', '')
        if error_msg:
            # 简化错误信息
            if 'syntax' in error_msg.lower():
                key = '语法错误'
            elif 'undefined' in error_msg.lower():
                key = '未定义标识符'
            elif 'expected' in error_msg.lower():
                key = '缺少符号'
            elif 'timeout' in error_msg.lower():
                key = '执行超时'
            else:
                key = '其他错误'
            
            error_counts[key] = error_counts.get(key, 0) + 1
    
    if error_counts:
        for error_type, count in error_counts.items():
            percentage = (count / len(results)) * 100
            print(f"{error_type}: {count} 次 ({percentage:.1f}%)")
    else:
        print("无错误记录")
    
    # 4. 代码质量分析
    print("\n📝 代码质量分析")
    print("-"*40)
    
    code_lengths = [r.get('validation_result', {}).get('code_length', 0) for r in results]
    valid_lengths = [l for l in code_lengths if l > 0]
    
    if valid_lengths:
        avg_length = sum(valid_lengths) / len(valid_lengths)
        min_length = min(valid_lengths)
        max_length = max(valid_lengths)
        
        print(f"平均代码长度: {avg_length:.0f} 字符")
        print(f"最短代码: {min_length} 字符")
        print(f"最长代码: {max_length} 字符")
        
        # 代码长度分布
        print("\n代码长度分布:")
        bins = [0, 100, 200, 500, 1000, float('inf')]
        labels = ['0-100', '101-200', '201-500', '501-1000', '1000+']
        
        for i in range(len(bins)-1):
            count = sum(1 for l in valid_lengths if bins[i] <= l < bins[i+1])
            percentage = (count / len(valid_lengths)) * 100
            if count > 0:
                print(f"  {labels[i]} 字符: {count} 个 ({percentage:.1f}%)")
    
    # 5. 改进建议
    print("\n💡 改进建议")
    print("-"*40)
    
    suggestions = []
    
    if basic_rate < 80:
        suggestions.append("1. 优化AI提示词，确保生成代码包含必要的基础结构（main函数、返回值等）")
    
    if compile_rate < 70:
        suggestions.append("2. 加强语法检查，减少编译错误")
        suggestions.append("3. 添加预编译验证步骤")
    
    if exec_rate < 50:
        suggestions.append("4. 改进算法逻辑生成，确保程序能够正确执行")
    
    suggestions.append("5. 增加更多样化的测试用例类型")
    suggestions.append("6. 添加代码风格规范检查")
    suggestions.append("7. 考虑集成单元测试验证功能正确性")
    
    for i, suggestion in enumerate(suggestions, 1):
        print(suggestion)
    
    # 6. 生成可视化报告
    print("\n📈 可视化报告生成中...")
    
    # 创建图表
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    # 通过率柱状图
    categories = ['基础验证', '编译验证', '执行验证']
    rates = [basic_rate, compile_rate, exec_rate]
    colors = ['#4CAF50', '#2196F3', '#FF9800']
    
    axes[0, 0].bar(categories, rates, color=colors)
    axes[0, 0].set_title('各阶段通过率')
    axes[0, 0].set_ylabel('通过率 (%)')
    axes[0, 0].set_ylim(0, 100)
    for i, v in enumerate(rates):
        axes[0, 0].text(i, v + 1, f'{v:.1f}%', ha='center')
    
    # 错误类型饼图
    if error_counts:
        axes[0, 1].pie(error_counts.values(), labels=error_counts.keys(), autopct='%1.1f%%')
        axes[0, 1].set_title('错误类型分布')
    else:
        axes[0, 1].text(0.5, 0.5, '无错误记录', ha='center', va='center')
        axes[0, 1].set_title('错误类型分布')
    
    # 代码长度分布
    if valid_lengths:
        axes[1, 0].hist(valid_lengths, bins=10, alpha=0.7, color='skyblue')
        axes[1, 0].set_title('代码长度分布')
        axes[1, 0].set_xlabel('代码长度 (字符)')
        axes[1, 0].set_ylabel('出现次数')
    
    # 性能评级
    grades_data = {
        '评级项目': ['基础验证', '编译验证'],
        '分数': [basic_rate, compile_rate],
        '等级': [basic_grade.split()[0], compile_grade.split()[0]]
    }
    
    axes[1, 1].axis('off')
    table_data = [[grades_data['评级项目'][i], 
                   f"{grades_data['分数'][i]:.1f}%", 
                   grades_data['等级'][i]] for i in range(2)]
    
    table = axes[1, 1].table(cellText=table_data,
                              colLabels=['项目', '通过率', '等级'],
                              cellLoc='center',
                              loc='center')
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 2)
    axes[1, 1].set_title('性能评级汇总')
    
    plt.suptitle('AI代码生成系统测试分析报告', fontsize=16, fontweight='bold')
    plt.tight_layout()
    
    # 保存图表
    report_dir = os.path.join(os.path.dirname(results_file), '..', 'analysis')
    os.makedirs(report_dir, exist_ok=True)
    chart_path = os.path.join(report_dir, f"analysis_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
    plt.savefig(chart_path, dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"\n✅ 分析报告图表已保存: {chart_path}")
    print("\n" + "="*80)
    print("分析完成！")
    print("="*80)
    
    return {
        'analysis': analysis,
        'error_counts': error_counts,
        'chart_path': chart_path
    }


if __name__ == "__main__":
    # 查找最新的测试结果文件
    report_dir = os.path.join(os.path.dirname(__file__), "reports")
    
    if os.path.exists(report_dir):
        json_files = [f for f in os.listdir(report_dir) if f.endswith('.json') and 'detailed' in f]
        
        if json_files:
            # 按修改时间排序，获取最新的文件
            json_files.sort(key=lambda x: os.path.getmtime(os.path.join(report_dir, x)), reverse=True)
            latest_file = os.path.join(report_dir, json_files[0])
            
            print(f"正在分析最新测试结果: {json_files[0]}")
            generate_analysis_report(latest_file)
        else:
            print("未找到测试结果文件，请先运行测试")
    else:
        print("报告目录不存在，请先运行测试")