#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    
    if (n < 0 || n > 20) {
        printf("0\n");
        return 0;
    }
    
    long long factorial = 1;
    for (int i = 1; i <= n; i++) {
        factorial *= i;
    }
    
    printf("%lld\n", factorial);
    
    return 0;
}