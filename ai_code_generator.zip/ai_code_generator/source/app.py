# app.py - 更新版
from flask import Flask, request, jsonify, send_from_directory, send_file, Response
import subprocess
import tempfile
import json
import os
import ast
import zipfile
import io
import requests
import re
import time
import traceback

app = Flask(__name__, static_folder=".", static_url_path="")

LM_URL = "http://192.168.8.241:1234/v1/chat/completions"
MODEL = "qwen/qwen3-4b-2507"

# ============================
#   调用 LLM（统一格式）
# ============================
def call_llm_raw(prompt: str, max_tokens: int = 1024, temperature: float = 0.7) -> str:
    """返回 LLM 的纯文本输出（不做 JSON 强制转换）"""
    try:
        payload = {
            "model": MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        resp = requests.post(LM_URL, json=payload, timeout=120)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"LLM调用错误: {str(e)}")
        return f"Error: {str(e)}"


def call_llm(prompt):
    """返回 JSON 结构的 LLM 输出"""
    try:
        payload = {
            "model": MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 1024,
            "temperature": 0.7
        }
        resp = requests.post(LM_URL, json=payload, timeout=120)
        resp.raise_for_status()
        data = resp.json()

        content = data["choices"][0]["message"]["content"]
        content = re.sub(r'\[?think\]?:?', '', content, flags=re.I)

        try:
            return json.loads(content)
        except:
            return {"code": content, "explain": ""}
    except Exception as e:
        return {"code": f"Error: {str(e)}", "explain": ""}

# ============================
#   你原有的所有接口（保持不动）
# ============================
@app.route("/")
def index():
    return send_from_directory(".", "index.html")


def build_prompt(user_prompt):
    return f"""
请严格按以下 JSON 格式返回：

{{
  "code": "只放代码，不要 ```，不要注释",
  "explain": "这里放讲解"
}}

下面是用户的需求，请按要求生成：
{user_prompt}
"""


@app.route("/send", methods=["POST"])
def send():
    data = request.get_json()
    prompt = data.get("prompt", "")
    if not prompt:
        return jsonify({"error": "empty prompt"}), 400

    content = call_llm(build_prompt(prompt))
    return jsonify(content)


@app.route("/stream", methods=["POST"])
def stream_code():
    data = request.get_json()
    prompt = data.get("prompt", "")

    if not prompt:
        return jsonify({"error": "empty prompt"}), 400

    def generate():
        full_prompt = build_prompt(prompt)
        response = call_llm(full_prompt)

        code = response.get("code", "")
        explain = response.get("explain", "")

        for i in range(0, len(code), 50):
            yield f"data: {json.dumps({'type': 'code', 'content': code[i:i+50]})}\n\n"
            time.sleep(0.05)

        for i in range(0, len(explain), 50):
            yield f"data: {json.dumps({'type': 'explain', 'content': explain[i:i+50]})}\n\n"
            time.sleep(0.05)

        yield "data: [DONE]\n\n"

    return Response(generate(), mimetype='text/plain')


@app.route("/optimize", methods=["POST"])
def optimize():
    data = request.get_json()
    code = data.get("code", "")

    prompt = f"""
请优化重构下面的代码，严格按 JSON 返回：
{{
  "code": "优化后的代码，不要注释",
  "explain": "说明你优化了什么"
}}
代码如下：
{code}
"""
    content = call_llm(prompt)
    return jsonify(content)


@app.route("/annotate", methods=["POST"])
def annotate():
    data = request.get_json()
    code = data.get("code", "")

    prompt = f"""
请为下面代码添加中文注释，结构不变：
{{
  "code": "带注释的代码",
  "explain": "主要逻辑讲解"
}}
代码如下：
{code}
"""
    content = call_llm(prompt)
    return jsonify(content)


@app.route("/explain", methods=["POST"])
def explain():
    data = request.get_json()
    code = data.get("code", "")

    prompt = f"""
请只讲解下面代码的含义，不要返回代码：
{{
  "code": "",
  "explain": "详细讲解内容"
}}
代码如下：
{code}
"""
    content = call_llm(prompt)
    return jsonify(content)


@app.route("/lint", methods=["POST"])
def lint():
    data = request.get_json()
    code = data.get("code", "")
    lang = data.get("lang", "").lower()

    if "python" in lang:
        try:
            ast.parse(code)
            return jsonify({"ok": True, "msg": "语法正确"})
        except Exception as e:
            return jsonify({"ok": False, "msg": str(e)})

    elif "js" in lang:
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".js") as f:
                f.write(code.encode("utf-8"))
                fname = f.name

            proc = subprocess.run(["node", "--check", fname],
                                  capture_output=True, text=True)

            if proc.returncode == 0:
                return jsonify({"ok": True, "msg": "语法正确"})
            return jsonify({"ok": False, "msg": proc.stderr})

        except Exception as e:
            return jsonify({"ok": False, "msg": str(e)})

    return jsonify({"ok": False, "msg": "语言不支持"})


@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    code = data.get("code", "")

    lines = len([l for l in code.split("\n") if l.strip()])
    funcs = len(re.findall(r"def |function ", code))
    branches = len(re.findall(r"\bif\b|\bfor\b|\bwhile\b|else|switch", code))
    complexity = max(1, branches)

    return jsonify({
        "lines": lines,
        "functions": funcs,
        "branches": branches,
        "complexity": complexity
    })


@app.route("/project", methods=["POST"])
def project():
    data = request.json
    ptype = data.get("type", "")

    mem = io.BytesIO()
    z = zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED)

    if ptype == "python-flask":
        z.writestr("app.py", "from flask import Flask\napp=Flask(__name__)\n@app.route('/')\ndef hi(): return 'Hello Flask'\n")
        z.writestr("requirements.txt", "flask")

    elif ptype == "node-express":
        z.writestr("index.js",
                   "const express=require('express');const app=express();app.get('/',(req,res)=>res.send('Hello Express'));app.listen(3000)")
        z.writestr("package.json",
                   '{"name":"demo","dependencies":{"express":"^4.18.2"}}')

    elif ptype == "java-spring":
        z.writestr("README.txt", "Spring Boot 项目骨架")
        z.writestr("pom.xml", "<!-- sample pom -->")

    z.close()
    mem.seek(0)

    return send_file(mem,
                     download_name=f"project_{ptype}.zip",
                     as_attachment=True)

# ============================================
# 🔥 新增：测试框架使用的 AI 接口 /api
# ============================================
@app.route("/api", methods=["POST"])
def api_generate():
    """
    pytest 的 test_full_ai_pipeline 会调用本接口：
    请求：
    { "prompt": "xxx", "type": "testcase" 或 "code" }

    返回：
    { 
      "success": true/false,
      "result": "LLM输出字符串",
      "error": "错误信息（如有）"
    }
    """
    try:
        data = request.get_json()
        prompt = data.get("prompt", "")
        req_type = data.get("type", "general")  # testcase, code, general
        
        if not prompt:
            return jsonify({
                "success": False,
                "result": "",
                "error": "empty prompt"
            }), 400

        # 根据类型调整提示词
        if req_type == "testcase":
            # 为测试用例生成专门的提示词 - 要求具体的输入输出数值
            enhanced_prompt = f"""
请生成一个C语言小程序的测试用例，包含以下JSON结构：
{{
    "description": "程序功能的简要描述（例如：计算一个整数的平方）",
    "input": "具体的输入值，例如：5",
    "output": "具体的预期输出值，例如：25",
    "constraints": "程序的限制条件",
    "example": "输入: 5 输出: 25"
}}

重要要求：
1. input字段必须是具体的输入值（数字或字符串），不是描述
2. output字段必须是具体的预期输出值（数字或字符串），不是描述
3. 如果程序需要多个输入，在input字段中用空格分隔，例如："5 10"
4. 输出应该是程序实际运行的结果，不包含提示文本

请确保返回的是纯JSON格式，不要包含其他任何文本。

{prompt}
"""
            result_text = call_llm_raw(enhanced_prompt, max_tokens=512, temperature=0.5)
            
        elif req_type == "code":
            # 为代码生成专门的提示词
            enhanced_prompt = f"""
根据以下需求生成完整的C语言程序代码：
{prompt}

要求：
1. 包含完整的main函数
2. 有明确的返回值
3. 包含必要的头文件
4. 代码结构清晰
5. 不要包含额外的解释，只返回代码
6. 如果程序需要输入，请使用scanf或命令行参数
7. 输出应该简洁，只包含结果

请直接返回代码，不要包含其他内容。
"""
            result_text = call_llm_raw(enhanced_prompt, max_tokens=2048, temperature=0.3)
            
        else:
            # 通用提示词
            result_text = call_llm_raw(prompt)

        return jsonify({
            "success": True,
            "result": result_text,
            "type": req_type
        })

    except Exception as e:
        error_msg = f"API调用错误: {str(e)}\n{traceback.format_exc()}"
        print(error_msg)
        return jsonify({
            "success": False,
            "result": "",
            "error": error_msg
        }), 500


@app.route("/api/health", methods=["GET"])
def api_health():
    """健康检查接口"""
    return jsonify({
        "status": "ok",
        "timestamp": time.time(),
        "model": MODEL,
        "endpoint": LM_URL
    })


@app.route("/api/compile", methods=["POST"])
def api_compile():
    """
    编译C代码的接口
    """
    try:
        data = request.get_json()
        code = data.get("code", "")
        test_input = data.get("input", "")
        
        if not code:
            return jsonify({
                "success": False,
                "error": "empty code"
            }), 400
        
        # 创建临时文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
            f.write(code)
            c_file = f.name
        
        try:
            # 编译
            exe_file = c_file.replace('.c', '.exe' if os.name == 'nt' else '.out')
            compile_result = subprocess.run(
                ['gcc', c_file, '-o', exe_file],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            compile_info = {
                "returncode": compile_result.returncode,
                "stdout": compile_result.stdout,
                "stderr": compile_result.stderr,
                "success": compile_result.returncode == 0
            }
            
            # 如果编译成功，尝试运行
            if compile_result.returncode == 0 and os.path.exists(exe_file):
                try:
                    run_result = subprocess.run(
                        [exe_file],
                        input=test_input if test_input else "",
                        capture_output=True,
                        text=True,
                        timeout=5
                    )
                    
                    run_info = {
                        "returncode": run_result.returncode,
                        "stdout": run_result.stdout,
                        "stderr": run_result.stderr,
                        "success": run_result.returncode == 0
                    }
                    
                except subprocess.TimeoutExpired:
                    run_info = {
                        "success": False,
                        "error": "程序执行超时"
                    }
                except Exception as e:
                    run_info = {
                        "success": False,
                        "error": str(e)
                    }
            else:
                run_info = {
                    "success": False,
                    "error": "编译失败，无法运行"
                }
            
        finally:
            # 清理临时文件
            try:
                os.unlink(c_file)
                if os.path.exists(exe_file):
                    os.unlink(exe_file)
            except:
                pass
        
        return jsonify({
            "success": compile_info["success"],
            "compile": compile_info,
            "run": run_info
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route("/api/batch", methods=["POST"])
def api_batch():
    """
    批量处理接口，用于一次生成多个测试用例
    """
    try:
        data = request.get_json()
        count = data.get("count", 1)
        req_type = data.get("type", "testcase")
        
        if count > 10:
            return jsonify({
                "success": False,
                "error": "批量生成数量不能超过10个"
            }), 400
        
        results = []
        for i in range(count):
            if req_type == "testcase":
                # 生成具体的测试用例
                prompt = "生成一个C语言程序测试用例，要求输入和输出都是具体的数值"
                result = call_llm_raw(prompt, max_tokens=512, temperature=0.6)
            else:
                prompt = "生成一个简单的C语言程序，计算两个数的和"
                result = call_llm_raw(prompt, max_tokens=1024, temperature=0.4)
            
            results.append({
                "id": i + 1,
                "result": result
            })
            
            # 避免请求过快
            time.sleep(0.5)
        
        return jsonify({
            "success": True,
            "count": count,
            "results": results
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

# ============================
# 启动
# ============================
if __name__ == "__main__":
    print("=" * 60)
    print("AI代码生成系统启动")
    print(f"模型: {MODEL}")
    print(f"API地址: {LM_URL}")
    print("服务运行在 http://0.0.0.0:5000")
    print("健康检查: http://127.0.0.1:5000/api/health")
    print("=" * 60)
    
    app.run(host="0.0.0.0", port=5000, debug=True, threaded=True)