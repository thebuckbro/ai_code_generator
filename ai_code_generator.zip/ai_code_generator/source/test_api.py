# test_api_enhanced_fixed.py
import json
import os
import subprocess
import tempfile
import re
import pytest
from datetime import datetime
from typing import Dict, List, Tuple, Any
import statistics
import matplotlib.pyplot as plt
import platform
import matplotlib
from matplotlib.font_manager import FontProperties, fontManager

# 导入更新后的客户端
try:
    from ai_client import ai_generate_testcase, ai_generate_code, check_api_health
except ImportError:
    # 如果导入失败，创建空函数
    def ai_generate_testcase():
        return {"description": "测试用例", "input": "5 10", "output": "15"}
    
    def ai_generate_code(testcase):
        return "#include <stdio.h>\nint main() { return 0; }"
    
    def check_api_health():
        return True

from docx import Document
from docx.shared import Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
CASE_DIR = os.path.join(BASE_DIR, "test_cases")
CODE_DIR = os.path.join(BASE_DIR, "generated_code")
REPORT_DIR = os.path.join(BASE_DIR, "reports")
ANALYSIS_DIR = os.path.join(BASE_DIR, "analysis")

os.makedirs(CASE_DIR, exist_ok=True)
os.makedirs(CODE_DIR, exist_ok=True)
os.makedirs(REPORT_DIR, exist_ok=True)
os.makedirs(ANALYSIS_DIR, exist_ok=True)


def save_json(path, data):
    """保存 JSON 数据"""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def load_json(path):
    """加载 JSON 数据"""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def clean_output(output_text: str) -> str:
    """
    清理输出，提取数字或文本，但保留必要的格式
    """
    if not output_text:
        return ""
    
    # 移除常见的提示文本
    prompt_patterns = [
        r'请输入.*[:：]',
        r'输入.*[:：]', 
        r'输出.*[:：]',
        r'结果.*[:：]',
        r'请输入',
        r'输入',
        r'输出',
        r'结果',
        r'是',
        r'为',
        r':',
        r'：'
    ]
    
    cleaned = output_text
    for pattern in prompt_patterns:
        cleaned = re.sub(pattern, '', cleaned)
    
    # 如果输出包含空格（如多个结果），保留整个输出
    if ' ' in cleaned or '\n' in cleaned:
        # 保留整个输出，只移除首尾空白
        cleaned = cleaned.strip()
        # 将多个空白替换为单个空格
        cleaned = re.sub(r'\s+', ' ', cleaned)
        return cleaned
    
    # 提取数字（包括小数）
    numbers = re.findall(r'-?\d+(?:\.\d+)?', cleaned)
    if numbers:
        # 如果有多个数字，返回所有数字用空格分隔
        if len(numbers) > 1:
            return ' '.join(numbers)
        # 如果只有一个数字，返回它
        return numbers[0]
    else:
        # 如果没有数字，返回清理后的文本
        cleaned = cleaned.strip()
        cleaned = re.sub(r'\s+', ' ', cleaned)
        return cleaned


def extract_input_values(input_desc: str) -> str:
    """
    从输入描述中提取具体的输入值
    支持任意数量的输入
    """
    if not input_desc:
        return "5 10"  # 默认值
    
    # 首先尝试直接返回，因为AI生成的测试用例input字段应该已经是具体的值
    # 检查是否只包含数字、空格、小数点、负号
    cleaned = input_desc.strip()
    if re.match(r'^[0-9\s\.\-]+$', cleaned):
        # 如果只包含数字、空格、小数点、负号，直接返回
        return cleaned
    
    # 提取所有数字（包括小数和负数）
    numbers = re.findall(r'-?\d+(?:\.\d+)?', input_desc)
    if numbers:
        # 返回所有数字，用空格分隔
        return ' '.join(numbers)
    
    # 如果是描述性文字，尝试根据常见模式提供默认值
    desc = input_desc.lower()
    if '两个整数' in desc or '两个数' in desc:
        return "5 10"
    elif '一个整数' in desc or '一个数' in desc:
        return "5"
    elif '三个整数' in desc or '三个数' in desc:
        return "5 10 15"
    elif '数组' in desc or '多个' in desc or '列表' in desc:
        # 对于数组，提供一组数字
        return "5 1 2 3 4 5"
    elif '方程' in desc or '二次' in desc:
        # 对于二次方程，提供系数
        return "1 -3 2"
    elif '温度' in desc:
        # 对于温度转换
        return "0"
    elif '素数' in desc:
        # 对于素数判断，提供几个测试数字
        return "2 3 4 5 17 20"
    else:
        return input_desc.strip()  # 直接返回原始值


def compile_and_run_c(code_text: str, test_input: str = None, testcase: Dict = None, use_args: bool = False) -> Tuple[bool, str, str]:
    """
    编译并运行 C 代码，支持标准输入和命令行参数
    增加对数组输入的处理
    """
    import tempfile
    import subprocess
    import os
    
    current_os = platform.system()
    
    # 创建临时C文件，使用UTF-8编码
    with tempfile.NamedTemporaryFile(
        mode='w', 
        suffix='.c', 
        delete=False, 
        encoding='utf-8'
    ) as f:
        f.write(code_text)
        c_file = f.name
    
    try:
        # 编译文件
        if current_os == "Windows":
            exe_file = c_file.replace('.c', '.exe')
            compile_result = subprocess.run(
                ['gcc', c_file, '-o', exe_file],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='ignore',
                timeout=10,
                shell=True,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
        else:
            exe_file = c_file.replace('.c', '.out')
            compile_result = subprocess.run(
                ['gcc', c_file, '-o', exe_file],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='ignore',
                timeout=10
            )
        
        if compile_result.returncode != 0:
            return False, "", compile_result.stderr or "编译失败"
        
        # 确定输入数据
        actual_input = ""
        if test_input:
            actual_input = test_input
        elif testcase and testcase.get('input'):
            actual_input = testcase.get('input', '')
        
        # 检查是否需要数组格式（第一个数字是长度）
        if testcase:
            description = testcase.get('description', '').lower()
            if any(keyword in description for keyword in ['数组', '列表', '多个数', '一组']):
                # 确保输入格式正确
                parts = actual_input.split()
                if parts and parts[0].isdigit():
                    # 已经是正确的数组格式
                    pass
                else:
                    # 转换为数组格式
                    numbers = re.findall(r'-?\d+', actual_input)
                    if numbers:
                        actual_input = f"{len(numbers)} {' '.join(numbers)}"
        
        print(f"   提供给程序的输入: '{actual_input}'")
        print(f"   输入方式: {'命令行参数' if use_args else '标准输入'}")
        
        # 运行程序
        if use_args:
            # 使用命令行参数
            args_list = []
            if actual_input:
                # 将输入字符串分割成参数
                args_list = actual_input.split()
            
            if current_os == "Windows":
                run_result = subprocess.run(
                    [exe_file] + args_list,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='ignore',
                    timeout=5,
                    shell=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
            else:
                run_result = subprocess.run(
                    [exe_file] + args_list,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='ignore',
                    timeout=5
                )
        else:
            # 使用标准输入
            if current_os == "Windows":
                run_result = subprocess.run(
                    [exe_file],
                    input=actual_input,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='ignore',
                    timeout=5,
                    shell=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
            else:
                run_result = subprocess.run(
                    [exe_file],
                    input=actual_input,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='ignore',
                    timeout=5
                )
        
        # 清理临时文件
        try:
            os.unlink(c_file)
            if os.path.exists(exe_file):
                os.unlink(exe_file)
        except:
            pass
            
        return True, run_result.stdout, run_result.stderr
        
    except subprocess.TimeoutExpired:
        return False, "", "程序执行超时"
    except Exception as e:
        return False, "", f"执行错误: {str(e)}"


def should_use_args(code_text: str, testcase: Dict) -> bool:
    """
    判断是否应该使用命令行参数
    """
    # 检查代码中是否使用argc/argv
    if "argc" in code_text or "argv" in code_text:
        return True
    
    # 检查测试用例描述
    desc = testcase.get('description', '').lower()
    input_desc = testcase.get('input', '').lower()
    
    if '命令行' in desc or '命令行' in input_desc:
        return True
    
    if '参数' in input_desc and ('传入' in input_desc or '传递' in input_desc):
        return True
    
    # 检查代码中是否使用main的参数
    if "main(" in code_text:
        # 查找main函数
        lines = code_text.split('\n')
        for line in lines:
            if 'main(' in line and ')' in line:
                if 'int' in line and ('argc' in line or 'argv' in line or 'char' in line):
                    return True
    
    return False


def validate_generated_c_with_details(code_text: str, testcase: Dict = None) -> Tuple[Dict, str, str]:
    """
    全面验证生成的 C 代码，返回更多细节
    返回 (验证结果字典, 实际输出, 错误信息)
    """
    validation_result = {
        "basic_validation": False,
        "compile_success": False,
        "execution_success": False,
        "output_match": False,
        "code_length": len(code_text),
        "has_main_function": False,
        "has_return": False,
        "error_message": ""
    }
    
    actual_output = ""
    error_msg = ""
    
    # 1. 基础关键字验证
    keywords = ["main", "return", "{", "}", ";"]
    validation_result["basic_validation"] = all(k in code_text for k in keywords)
    validation_result["has_main_function"] = "main" in code_text.lower()
    validation_result["has_return"] = "return" in code_text.lower()
    
    # 2. 尝试编译
    if validation_result["basic_validation"]:
        # 判断是否使用命令行参数
        use_args = should_use_args(code_text, testcase) if testcase else False
        
        # 根据测试用例确定输入
        input_for_program = None
        if testcase and testcase.get('input'):
            input_desc = testcase.get('input', '')
            # 提取具体的输入值
            input_for_program = extract_input_values(input_desc)
        
        compile_success, stdout, stderr = compile_and_run_c(code_text, input_for_program, testcase, use_args)
        validation_result["compile_success"] = compile_success
        validation_result["error_message"] = stderr
        error_msg = stderr
        
        # 保存实际输出
        actual_output = stdout.strip()
        
        # 3. 如果编译成功
        if compile_success:
            validation_result["execution_success"] = True
            
            expected_output = testcase.get('output', '').strip() if testcase else ''
            
            # 如果预期输出不为空，检查匹配
            if expected_output:
                # 清理实际输出和预期输出
                cleaned_actual = clean_output(actual_output)
                cleaned_expected = clean_output(expected_output)
                
                # 打印调试信息
                print(f"   🔍 输出匹配检查:")
                print(f"      预期输出: '{expected_output}'")
                print(f"      实际输出: '{actual_output}'")
                print(f"      清理后期望: '{cleaned_expected}'")
                print(f"      清理后实际: '{cleaned_actual}'")
                
                # 比较清理后的输出
                validation_result["output_match"] = (cleaned_expected == cleaned_actual)
    
    return validation_result, actual_output, error_msg


def validate_generated_c(code_text: str, testcase: Dict = None) -> Dict:
    """
    兼容原接口的验证函数
    """
    validation_result, _, _ = validate_generated_c_with_details(code_text, testcase)
    return validation_result


def analyze_test_results(results: List[Dict]) -> Dict:
    """
    分析测试结果，生成统计数据
    """
    if not results:
        return {}
    
    total_cases = len(results)
    passed_cases = sum(1 for r in results if r.get("validation_result", {}).get("basic_validation", False))
    compile_success = sum(1 for r in results if r.get("validation_result", {}).get("compile_success", False))
    execution_success = sum(1 for r in results if r.get("validation_result", {}).get("execution_success", False))
    
    # 计算输出匹配率
    output_match = sum(1 for r in results if r.get("validation_result", {}).get("output_match", False))
    
    # 计算代码长度统计
    code_lengths = [r.get("validation_result", {}).get("code_length", 0) for r in results if r.get("validation_result", {}).get("code_length", 0) > 0]
    
    return {
        "total_cases": total_cases,
        "passed_basic": passed_cases,
        "compile_success": compile_success,
        "execution_success": execution_success,
        "output_match": output_match,
        "basic_pass_rate": passed_cases / total_cases * 100 if total_cases > 0 else 0,
        "compile_pass_rate": compile_success / total_cases * 100 if total_cases > 0 else 0,
        "execution_pass_rate": execution_success / total_cases * 100 if total_cases > 0 else 0,
        "output_match_rate": output_match / total_cases * 100 if total_cases > 0 else 0,
        "avg_code_length": statistics.mean(code_lengths) if code_lengths else 0,
        "min_code_length": min(code_lengths) if code_lengths else 0,
        "max_code_length": max(code_lengths) if code_lengths else 0,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }


def setup_chinese_font():
    """设置中文字体"""
    system_os = platform.system()
    
    # Windows系统字体路径
    if system_os == 'Windows':
        windows_fonts = [
            'C:/Windows/Fonts/simhei.ttf',
            'C:/Windows/Fonts/msyh.ttc',
            'C:/Windows/Fonts/msyhbd.ttc',
            'C:/Windows/Fonts/simsun.ttc',
            'C:/Windows/Fonts/simkai.ttf',
        ]
        
        for font_path in windows_fonts:
            if os.path.exists(font_path):
                try:
                    font_prop = FontProperties(fname=font_path)
                    fontManager.addfont(font_path)
                    font_name = font_prop.get_name()
                    
                    plt.rcParams['font.sans-serif'] = [font_name, 'Microsoft YaHei', 'SimHei', 'DejaVu Sans']
                    plt.rcParams['axes.unicode_minus'] = False
                    print(f"已设置中文字体: {font_name}")
                    return True
                except Exception as e:
                    print(f"设置字体 {font_path} 失败: {e}")
                    continue
        
        print("警告: 未找到可用的中文字体，将使用英文标签")
        return False
    
    # macOS系统
    elif system_os == 'Darwin':
        mac_fonts = [
            '/System/Library/Fonts/PingFang.ttc',
            '/System/Library/Fonts/STHeiti Light.ttc',
            '/System/Library/Fonts/STHeiti Medium.ttc',
        ]
        
        for font_path in mac_fonts:
            if os.path.exists(font_path):
                try:
                    font_prop = FontProperties(fname=font_path)
                    fontManager.addfont(font_path)
                    font_name = font_prop.get_name()
                    plt.rcParams['font.sans-serif'] = [font_name, 'Arial Unicode MS', 'Hiragino Sans GB']
                    plt.rcParams['axes.unicode_minus'] = False
                    print(f"已设置中文字体: {font_name}")
                    return True
                except:
                    continue
        
        print("警告: 未找到可用的中文字体，将使用英文标签")
        return False
    
    # Linux系统
    else:
        linux_fonts = [
            '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
            '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
        ]
        
        for font_path in linux_fonts:
            if os.path.exists(font_path):
                try:
                    font_prop = FontProperties(fname=font_path)
                    fontManager.addfont(font_path)
                    font_name = font_prop.get_name()
                    plt.rcParams['font.sans-serif'] = [font_name, 'WenQuanYi Micro Hei', 'DejaVu Sans']
                    plt.rcParams['axes.unicode_minus'] = False
                    print(f"已设置中文字体: {font_name}")
                    return True
                except:
                    continue
        
        print("警告: 未找到可用的中文字体，将使用英文标签")
        return False


def generate_analysis_chart(results: List[Dict], analysis: Dict):
    """生成分析图表"""
    if not results:
        return None
    
    # 尝试设置中文字体
    has_chinese_font = setup_chinese_font()
    
    if has_chinese_font:
        labels = ['基础验证通过', '编译成功', '执行成功', '输出匹配']
        title = 'AI代码生成测试结果分析'
        ylabel = '通过率 (%)'
    else:
        labels = ['Basic Validation', 'Compile Success', 'Execution Success', 'Output Match']
        title = 'AI Code Generation Test Results'
        ylabel = 'Pass Rate (%)'
    
    values = [
        analysis['basic_pass_rate'],
        analysis['compile_pass_rate'],
        analysis['execution_pass_rate'],
        analysis['output_match_rate']
    ]
    
    colors = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0']
    
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.bar(labels, values, color=colors)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_ylim(0, 100)
    
    # 在柱状图上显示数值
    for bar, value in zip(bars, values):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height + 1,
                f'{value:.1f}%', ha='center', va='bottom', fontsize=10)
    
    # 添加网格线
    ax.yaxis.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    
    # 保存图表
    chart_path = os.path.join(ANALYSIS_DIR, f"analysis_chart_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
    plt.savefig(chart_path, dpi=150, bbox_inches='tight')
    plt.close()
    
    return chart_path


def test_full_ai_pipeline_enhanced(num_cases: int = 5):
    """
    增强版AI测试管线 - 显示更多细节
    """
    results = []
    print(f"\n{'='*60}")
    print(f"开始执行AI代码生成测试，共 {num_cases} 个用例")
    print(f"{'='*60}")

    for case_id in range(1, num_cases + 1):
        print(f"\n{'='*40}")
        print(f"测试用例 {case_id}/{num_cases}")
        print(f"{'='*40}")
        
        try:
            # ① 调用 AI 生成测试用例
            print("1️⃣ 生成测试用例...")
            testcase = ai_generate_testcase()
            case_path = os.path.join(CASE_DIR, f"case_{case_id:03d}.json")
            save_json(case_path, testcase)
            
            # 显示测试用例详情
            print("   测试用例详情:")
            print(f"   描述: {testcase.get('description', 'N/A')}")
            print(f"   输入: {testcase.get('input', 'N/A')}")
            print(f"   预期输出: {testcase.get('output', 'N/A')}")
            if testcase.get('constraints'):
                print(f"   限制: {testcase.get('constraints')}")
            
            # ② 用测试用例向 AI 请求生成 C 代码
            print("\n2️⃣ 生成C代码...")
            code_text = ai_generate_code(testcase)
            code_path = os.path.join(CODE_DIR, f"code_{case_id:03d}.c")
            with open(code_path, "w", encoding="utf-8") as f:
                f.write(code_text)
            
            # 显示代码片段
            print(f"   代码长度: {len(code_text)} 字符")
            print(f"   代码前5行:")
            lines = code_text.split('\n')[:5]
            for i, line in enumerate(lines, 1):
                line_preview = line[:100] + ('...' if len(line) > 100 else '')
                print(f"      {i:2d}. {line_preview}")
            
            # 显示完整代码
            print("\n4️⃣ 生成的完整代码:")
            print("=" * 60)
            print(code_text)
            print("=" * 60)
            
            # ③ 执行全面验证 - 获取实际输出
            print("\n3️⃣ 验证生成的代码...")
            validation_result, actual_output, error_msg = validate_generated_c_with_details(code_text, testcase)
            
            # 显示验证结果
            expected_output = testcase.get('output', 'N/A')
            cleaned_expected = clean_output(expected_output)
            cleaned_actual = clean_output(actual_output)
            
            print(f"\n🔍 详细输出对比:")
            print(f"   实际输出: '{actual_output if actual_output else '无输出'}'")
            print(f"   预期输出: '{expected_output}'")
            print(f"   清理后的实际输出: '{cleaned_actual}'")
            print(f"   清理后的预期输出: '{cleaned_expected}'")
            print(f"   输出匹配: {'✅' if validation_result.get('output_match', False) else '❌'}")
            print(f"   编译状态: {'✅ 成功' if validation_result.get('compile_success', False) else '❌ 失败'}")
            if error_msg:
                print(f"   错误信息: {error_msg[:100]}{'...' if len(error_msg) > 100 else ''}")
            
            # 记录结果
            result = {
                "id": case_id,
                "testcase": testcase,
                "code_file": code_path,
                "validation_result": validation_result,
                "actual_output": actual_output,
                "cleaned_actual_output": cleaned_actual,
                "cleaned_expected_output": cleaned_expected,
                "error_message": error_msg,
                "timestamp": datetime.now().isoformat()
            }
            
            results.append(result)
            
            # 打印当前用例结果总结
            print(f"\n📋 用例 {case_id} 结果:")
            print(f"   基础验证: {'✅ 通过' if validation_result['basic_validation'] else '❌ 失败'}")
            print(f"   编译: {'✅ 成功' if validation_result['compile_success'] else '❌ 失败'}")
            print(f"   执行: {'✅ 成功' if validation_result['execution_success'] else '❌ 失败'}")
            print(f"   输出匹配: {'✅ 是' if validation_result.get('output_match', False) else '❌ 否'}")
            
        except Exception as e:
            print(f"❌ 错误: 用例 {case_id} 执行失败 - {str(e)}")
            results.append({
                "id": case_id,
                "error": str(e),
                "validation_result": {
                    "basic_validation": False,
                    "compile_success": False,
                    "execution_success": False,
                    "error_message": str(e)
                },
                "timestamp": datetime.now().isoformat()
            })

    # ④ 分析结果
    print(f"\n{'='*60}")
    print("正在分析测试结果...")
    analysis = analyze_test_results(results)
    
    # ⑤ 保存详细测试结果
    detailed_path = os.path.join(REPORT_DIR, f"detailed_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    save_json(detailed_path, {
        "results": results,
        "analysis": analysis,
        "summary": {
            "total_cases": analysis["total_cases"],
            "basic_pass_rate": f"{analysis['basic_pass_rate']:.2f}%",
            "compile_pass_rate": f"{analysis['compile_pass_rate']:.2f}%",
            "execution_pass_rate": f"{analysis['execution_pass_rate']:.2f}%",
            "output_match_rate": f"{analysis['output_match_rate']:.2f}%"
        }
    })
    
    # ⑥ 生成分析图表
    chart_path = generate_analysis_chart(results, analysis)
    
    # ⑦ 生成Word报告
    report_path = generate_word_report_enhanced(results, analysis, chart_path)
    
    # ⑧ 打印最终统计
    print("\n" + "="*60)
    print("🏆 测试完成！最终统计结果：")
    print("="*60)
    print(f"📊 总测试用例数: {analysis['total_cases']}")
    print(f"✅ 基础验证通过率: {analysis['basic_pass_rate']:.2f}% ({analysis['passed_basic']}/{analysis['total_cases']})")
    print(f"✅ 编译成功率: {analysis['compile_pass_rate']:.2f}% ({analysis['compile_success']}/{analysis['total_cases']})")
    print(f"✅ 执行成功率: {analysis['execution_pass_rate']:.2f}% ({analysis['execution_success']}/{analysis['total_cases']})")
    print(f"✅ 输出匹配率: {analysis['output_match_rate']:.2f}% ({analysis['output_match']}/{analysis['total_cases']})")
    print(f"📏 平均代码长度: {analysis['avg_code_length']:.0f} 字符")
    print(f"📏 最短代码: {analysis['min_code_length']} 字符")
    print(f"📏 最长代码: {analysis['max_code_length']} 字符")
    print(f"\n📄 详细报告: {report_path}")
    print(f"📈 分析图表: {chart_path}")
    print("="*60)
    
    return results, analysis


def generate_word_report_enhanced(results: List[Dict], analysis: Dict, chart_path: str = None):
    """生成增强版Word实验报告 - 显示更多细节"""
    doc = Document()
    
    # 标题
    title = doc.add_heading("AI代码生成系统 - 详细测试报告", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 基本信息
    doc.add_paragraph(f"📅 生成时间: {analysis['timestamp']}")
    doc.add_paragraph(f"📊 测试用例总数: {analysis['total_cases']}")
    
    # 一、测试概述
    doc.add_heading("一、测试概述", level=1)
    doc.add_paragraph(
        "本次实验旨在评估AI代码生成系统的性能。系统通过AI自动生成C语言测试用例，"
        "并根据这些用例生成对应的C代码。测试框架对生成的代码进行多层次验证，"
        "包括基础结构验证、编译验证和执行验证。"
    )
    
    # 二、测试结果总览
    doc.add_heading("二、测试结果总览", level=1)
    
    # 创建表格显示统计结果
    table = doc.add_table(rows=6, cols=3)
    table.style = 'Light Shading Accent 1'
    
    # 表头
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = "测试项目"
    hdr_cells[1].text = "通过数量"
    hdr_cells[2].text = "通过率"
    
    # 数据行
    data_rows = [
        ("基础验证", f"{analysis['passed_basic']}/{analysis['total_cases']}", f"{analysis['basic_pass_rate']:.2f}%"),
        ("编译验证", f"{analysis['compile_success']}/{analysis['total_cases']}", f"{analysis['compile_pass_rate']:.2f}%"),
        ("执行验证", f"{analysis['execution_success']}/{analysis['total_cases']}", f"{analysis['execution_pass_rate']:.2f}%"),
        ("输出匹配", f"{analysis['output_match']}/{analysis['total_cases']}", f"{analysis['output_match_rate']:.2f}%"),
        ("代码长度统计", f"平均: {analysis['avg_code_length']:.0f}字符", f"范围: {analysis['min_code_length']}-{analysis['max_code_length']}字符")
    ]
    
    for i, (project, count, rate) in enumerate(data_rows, 1):
        row_cells = table.rows[i].cells
        row_cells[0].text = project
        row_cells[1].text = count
        row_cells[2].text = rate
    
    # 如果存在图表，插入图表
    if chart_path and os.path.exists(chart_path):
        doc.add_heading("三、测试结果可视化", level=1)
        doc.add_paragraph("以下是本次测试的通过率分析图表：")
        try:
            doc.add_picture(chart_path, width=Inches(6))
        except:
            doc.add_paragraph("（图表加载失败）")
    
    # 四、详细测试结果
    doc.add_heading("四、详细测试结果", level=1)
    doc.add_paragraph("以下是每个测试用例的详细执行情况：")
    
    for i, r in enumerate(results, 1):
        doc.add_heading(f"测试用例 {r['id']:03d}", level=2)
        
        # 用例信息表格
        case_table = doc.add_table(rows=6, cols=2)
        case_table.style = 'Table Grid'
        
        # 测试用例详情
        case_data = [
            ("📝 描述", r.get('testcase', {}).get('description', 'N/A')),
            ("📥 输入", r.get('testcase', {}).get('input', '无')),
            ("📤 预期输出", r.get('testcase', {}).get('output', 'N/A')),
            ("📤 实际输出", r.get('actual_output', 'N/A')),
            ("⚙️ 限制条件", r.get('testcase', {}).get('constraints', '无')),
            ("📄 示例", r.get('testcase', {}).get('example', '无'))
        ]
        
        for row_idx, (label, value) in enumerate(case_data):
            case_table.cell(row_idx, 0).text = label
            case_table.cell(row_idx, 1).text = str(value)
        
        doc.add_paragraph()
        
        # 验证结果
        doc.add_heading("验证结果", level=3)
        
        validation = r.get('validation_result', {})
        result_table = doc.add_table(rows=5, cols=2)
        result_table.style = 'Table Grid'
        
        result_data = [
            ("✅ 基础验证", "通过" if validation.get('basic_validation', False) else "失败"),
            ("🔧 编译成功", "是" if validation.get('compile_success', False) else "否"),
            ("🚀 执行成功", "是" if validation.get('execution_success', False) else "否"),
            ("🔍 输出匹配", "是" if validation.get('output_match', False) else "否"),
            ("📏 代码长度", f"{validation.get('code_length', 0)} 字符")
        ]
        
        for row_idx, (label, value) in enumerate(result_data):
            result_table.cell(row_idx, 0).text = label
            result_table.cell(row_idx, 1).text = str(value)
        
        # 输出对比
        doc.add_heading("输出对比", level=3)
        output_table = doc.add_table(rows=5, cols=2)
        output_table.style = 'Table Grid'
        
        expected_output = r.get('testcase', {}).get('output', 'N/A')
        actual_output = r.get('actual_output', 'N/A')
        cleaned_expected = r.get('cleaned_expected_output', 'N/A')
        cleaned_actual = r.get('cleaned_actual_output', 'N/A')
        
        output_table.cell(0, 0).text = "项目"
        output_table.cell(0, 1).text = "内容"
        output_table.cell(1, 0).text = "预期输出"
        output_table.cell(1, 1).text = str(expected_output)
        output_table.cell(2, 0).text = "实际输出"
        output_table.cell(2, 1).text = str(actual_output)
        output_table.cell(3, 0).text = "清理后期望"
        output_table.cell(3, 1).text = str(cleaned_expected)
        output_table.cell(4, 0).text = "清理后实际"
        output_table.cell(4, 1).text = str(cleaned_actual)
        
        # 匹配状态
        match_status = "✅ 匹配" if validation.get('output_match', False) else "❌ 不匹配"
        doc.add_paragraph(f"匹配状态: {match_status}")
        
        # 错误信息（如果有）
        if validation.get('error_message'):
            doc.add_heading("错误信息", level=3)
            error_para = doc.add_paragraph()
            error_para.add_run("❌ ").bold = True
            error_para.add_run(validation['error_message'][:500])
            if len(validation['error_message']) > 500:
                error_para.add_run("... (更多内容请查看日志)")
        
        # 代码预览
        doc.add_heading("代码预览", level=3)
        code_preview = doc.add_paragraph()
        code_preview.add_run("（完整代码已保存到文件）").italic = True
        
        # 如果有代码文件，显示前20行
        code_file = r.get('code_file', '')
        if code_file and os.path.exists(code_file):
            try:
                with open(code_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()[:20]
                    if lines:
                        code_text = ''.join(lines)
                        code_preview.add_run(f"\n\n前20行代码:\n")
                        code_preview.add_run(code_text)
                        if len(lines) == 20:
                            code_preview.add_run("\n... (更多代码请查看文件)")
            except:
                pass
        
        doc.add_paragraph("-" * 50)
    
    # 五、结论与建议
    doc.add_heading("五、结论与建议", level=1)
    
    conclusion_text = f"""
本次测试共执行 {analysis['total_cases']} 个测试用例，详细结果如下：

1. 基础验证通过率: {analysis['basic_pass_rate']:.2f}%
2. 编译成功率: {analysis['compile_pass_rate']:.2f}%
3. 执行成功率: {analysis['execution_pass_rate']:.2f}%
4. 输出匹配率: {analysis['output_match_rate']:.2f}%
5. 代码平均长度: {analysis['avg_code_length']:.0f} 字符

"""
    
    if analysis['basic_pass_rate'] >= 90:
        conclusion_text += "✅ 系统在基础结构验证方面表现优秀，能够生成符合C语言基本结构的代码。\n"
    elif analysis['basic_pass_rate'] >= 80:
        conclusion_text += "✅ 系统在基础结构验证方面表现良好，能够生成符合C语言基本结构的代码。\n"
    elif analysis['basic_pass_rate'] >= 60:
        conclusion_text += "⚠️ 系统在基础结构验证方面表现一般，部分生成的代码结构不完整。\n"
    else:
        conclusion_text += "❌ 系统在基础结构验证方面表现不佳，需要改进代码生成策略。\n"
    
    if analysis['compile_pass_rate'] >= 80:
        conclusion_text += "✅ 系统在编译验证方面表现良好，大部分生成的代码能够成功编译。\n"
    elif analysis['compile_pass_rate'] >= 60:
        conclusion_text += "⚠️ 系统在编译验证方面表现一般，部分代码需要进一步调试。\n"
    else:
        conclusion_text += "❌ 系统在编译验证方面表现不佳，生成的代码存在较多语法错误。\n"
    
    if analysis['output_match_rate'] >= 80:
        conclusion_text += "✅ 系统在输出匹配方面表现良好，生成的代码能够正确输出预期结果。\n"
    elif analysis['output_match_rate'] >= 60:
        conclusion_text += "⚠️ 系统在输出匹配方面表现一般，部分代码输出与预期不符。\n"
    else:
        conclusion_text += "❌ 系统在输出匹配方面表现不佳，需要改进算法逻辑生成。\n"
    
    conclusion_text += f"\n改进建议：\n"
    conclusion_text += "1. 增加更多样化的测试用例，覆盖不同复杂度的编程任务\n"
    conclusion_text += "2. 优化AI提示词，提高生成代码的语法正确性\n"
    conclusion_text += "3. 添加代码风格检查，确保生成代码的可读性和规范性\n"
    conclusion_text += "4. 考虑添加单元测试验证，确保生成代码的功能正确性\n"
    conclusion_text += "5. 改进输出验证机制，提高输出匹配的准确性\n"
    
    doc.add_paragraph(conclusion_text)
    
    # 保存报告
    report_path = os.path.join(REPORT_DIR, f"report_detailed_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx")
    doc.save(report_path)
    print(f"详细版Word报告已生成：{report_path}")
    
    return report_path


def test_full_ai_pipeline():
    """原版测试函数，保持兼容性"""
    results = []

    for case_id in range(1, 6):   # 生成 5 个用例
        print(f"\n=== 开始执行测试用例 {case_id} ===")

        # ① 调用 AI 生成测试用例
        testcase = ai_generate_testcase()
        case_path = os.path.join(CASE_DIR, f"case_{case_id:03}.json")
        save_json(case_path, testcase)

        # ② 用测试用例向 AI 请求生成 C 代码
        code_text = ai_generate_code(testcase)
        code_path = os.path.join(CODE_DIR, f"code_{case_id:03}.c")
        with open(code_path, "w", encoding="utf-8") as f:
            f.write(code_text)

        # ③ 执行验证
        validation_result = validate_generated_c(code_text, testcase)
        passed = validation_result["basic_validation"]

        results.append({
            "id": case_id,
            "testcase": testcase,
            "passed": passed,
            "validation_result": validation_result,
            "code_file": code_path
        })

    # ④ 保存测试结果
    summary_path = os.path.join(REPORT_DIR, "summary.json")
    save_json(summary_path, results)

    # ⑤ 自动生成 Word 文档
    analysis = analyze_test_results(results)
    generate_word_report_enhanced(results, analysis)

    # ⑥ pytest 显示结果
    pass_rate = analysis["basic_pass_rate"] / 100
    print(f"\n测试完成，总通过率：{pass_rate*100:.2f}%")

    assert pass_rate > 0   # 确保流程正常执行


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="AI代码生成测试系统")
    parser.add_argument("--cases", type=int, default=5, help="测试用例数量")
    parser.add_argument("--enhanced", action="store_true", help="使用增强版测试")
    
    args = parser.parse_args()
    
    if args.enhanced:
        results, analysis = test_full_ai_pipeline_enhanced(args.cases)
    else:
        test_full_ai_pipeline()