#include <stdio.h>

int main() {
    int weight, height, age;
    float body_fat_rate;

    // 读取输入
    if (scanf("%d %d %d %d", &weight, &height, &age) != 4) {
        return 1;
    }

    // 验证输入范围
    if (weight < 10 || weight > 200 || height < 130 || height > 210 || age < 18 || age > 80) {
        return 1;
    }

    // 使用标准体脂率公式（简化版：体脂率 = 1.2 * 年龄 + 0.23 * 体重(kg) + 0.0001 * 身高(cm) - 5.0）
    body_fat_rate = 1.2 * age + 0.23 * weight + 0.0001 * height - 5.0;

    // 体脂率通常在10-30%之间，这里做合理范围调整
    body_fat_rate = (body_fat_rate < 10.0) ? 10.0 : (body_fat_rate > 30.0) ? 30.0 : body_fat_rate;

    printf("%.1f\n", body_fat_rate);

    return 0;
}