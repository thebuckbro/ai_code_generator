#include <stdio.h>

int main() {
    int n, arr[10];
    
    // 读取输入
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    
    // 计算阶乘和
    long long sum = 0;
    for (int i = 0; i < n; i++) {
        long long factorial = 1;
        for (int j = 1; j <= arr[i]; j++) {
            factorial *= j;
        }
        sum += factorial;
    }
    
    printf("%lld\n", sum);
    
    return 0;
}